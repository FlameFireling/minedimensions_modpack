castle_gates = {}

local modpath = minetest.get_modpath(minetest.get_current_modname())
dofile(modpath.."/doc.lua")
dofile(modpath.."/gate_functions.lua")
dofile(modpath.."/gate_slots.lua")
dofile(modpath.."/gates.lua")
dofile(modpath.."/doors.lua")
