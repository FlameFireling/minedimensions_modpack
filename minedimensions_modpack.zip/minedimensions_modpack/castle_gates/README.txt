Castle Gates

Licence: MIT

see: LICENSE

=-=-=-=-=-=-=-=-=-=

This is a mod all about creating castle gates and dungeons. It contains dungeon doors and bars, and also a set of nodes for constructing larger swinging and sliding gates.

This allows the construction of portcullises and drawbridges as well as conventional swinging doors. Use the screwdriver to reorient gate pieces as needed for these purposes.
