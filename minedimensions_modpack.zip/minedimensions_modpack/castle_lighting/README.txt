=-=-=-=-=-=-=-=-=-=

Castles Mod
by: Philipbenr And DanDuncombe

=-=-=-=-=-=-=-=-=-=

Licence: MIT

see: LICENSE

=-=-=-=-=-=-=-=-=-=

This mod contains medieval lighting sources suitable for a castle. It includes:

* Small chandelier and hanging chain
* Lantern box
* Steel floor brasier
* Stone pedestal/column brasier.

If the castle_masonry mod is installed, brasiers will be generated for all enabled material types.

Brasiers require fuel to generate a flame.