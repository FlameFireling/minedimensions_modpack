=-=-=-=-=-=-=
GloopTest :D *insert witty comment here*
=-=-=-=-=-=-=

Adds a collection of things into minetest. As it stands, this adds three different modules.

More (or possibly (most likely) less) imformation can be found here: http://minetest.net/forum/viewtopic.php?id=4345

--==--==--

Ore Module: Adds a variety of ores into minetest, for use here and possibly in other mods.

OtherGen Module: Adds generation aside from ores.

Parts Module: Adds some bits and bobs for machinery and some minor blocks.

Tech Module: Adds the "tech" of glooptest.

Tools Module: Adds extra kinds of tools.

Compat Module: Puts into place a number of aliases for cross-mod-compatibility.
