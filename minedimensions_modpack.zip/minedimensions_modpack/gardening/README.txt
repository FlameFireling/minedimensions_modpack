-=-

Gardening mod
-
By: philipbenr

-=-

Before use, realize this; This mod is purely decorative. It has crafting recipes, but no natural spawning abilities. Those may be added later with the removal of crafting.

-=-

License : WTFPL

-=-

Depends : Default, Minetest 0.4.7 or Flowers.

-=-

Crafting recipes
~~~~~~~~~~~~~~~~~
Packed Dirt = 

	Stone
	Sand
	Dirt

in any column
--------------
Rosebush = 

	Rose
	Leaves
	Tree

in any column
--------------
Violas = 

	Viola
	Leaves
	Tree

in any column
--------------
Geraniums = 

	Geranium
	Leaves
	Tree

in any column
--------------
Tulips = 

	Tulips
	Leaves
	Tree

in any column
--------------

Dandelions = 

	_, Yellow Dandelion, White Dandelion
	_, Leaves, _
	_, Tree, _

this is the only fixed recipe
--------------

-=-

Thats all for now.
