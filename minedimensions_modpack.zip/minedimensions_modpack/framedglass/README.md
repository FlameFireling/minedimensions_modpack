Framed Glass
============

Framed glass adds glass nodes with a frame that connects automatically to neighbouring nodes.

License
=======

Copyright (C) 2013 Maciej Kasatkin (RealBadAngel) and contributors.

All code and textures are licensed under the GNU LGPLv2+.

Credits for contributing:
  * VanessaE