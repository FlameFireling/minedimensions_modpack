=-=-=-=-=-=-=-=-=-=

Crafting Bench
by: Philipbenr And DanDuncombe

=-=-=-=-=-=-=-=-=-=

Licence: MIT

see: LICENSE

=-=-=-=-=-=-=-=-=-=

An auto-crafting bench. Place raw materials into its inventory, define a crafting recipe in its main grid, and then every five seconds it will generate a crafted output.

This mod is compatible with hoppers.

The crafting rate can be modified in advanced settings.