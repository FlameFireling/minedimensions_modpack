-- Disable to make the uranium only be "technic"uranium". Enable to add "display_blocks:uranium"
enable_display_uranium = false
--Enable to make "technic:uranium" spawning like "display_blocks:uranium".
technic_uranium_new_ore_gen = true
--Enable to add a recipe that uses "technic:uranium"
enable_technic_recipe = true
