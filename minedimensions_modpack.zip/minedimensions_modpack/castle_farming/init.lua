local MP = minetest.get_modpath(minetest.get_current_modname())

dofile(MP.."/hides.lua")
dofile(MP.."/straw.lua")