=-=-=-=-=-=-=-=-=-=

Castles Mod
by: Philipbenr And DanDuncombe

=-=-=-=-=-=-=-=-=-=

Licence: MIT

see: LICENSE

=-=-=-=-=-=-=-=-=-=

Contains farm products useful for decorating a castle:

* Hide wall and floor coverings
* Bound straw bale
* Straw training dummy

=-=-=-=-=-=-=-=-=-=
