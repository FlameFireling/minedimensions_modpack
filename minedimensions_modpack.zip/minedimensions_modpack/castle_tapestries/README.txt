=-=-=-=-=-=-=-=-=-=

Tapestries Mod
by: Philipbenr And DanDuncombe

=-=-=-=-=-=-=-=-=-=

Licence: MIT

see: LICENSE


This mod contains tapestries of three different lengths, and a wooden crosspiece to hang them from. The tapestries can be dyed any color once hung.